# APPLICATION CRUD EN PHP/MySQL

Ce projet est complet et grâce à lui vous aurez les bases de PHP pour créer des applications Web dynamiques.
On applique dans ce projet les requêtes SQL à savoir CREAD, READ, UPDATE, DELETE (CRUD) et gérons les sessions des
utilisateurs afin que l'application s'adapte à l'utilisateur connecté.

Nous parlons également de la fonction htmlspecialchars() pour protéger notre application contre les injections.

En effet, on réalise ici une application de publication d'avis, les utilisateurs donneront alors leurs avis sur l'application et pourront également 
les modifier ou les supprimer.

Vous pouvez voir la réalisation de cette application sur ma chaîne YouTube ici : 
https://www.youtube.com/watch?v=4kikcZZC3R4&list=PLTbw4SyEydLR_GRJDK6W5UgqiwajP9Sct&ab_channel=DimitriMintsa



 
